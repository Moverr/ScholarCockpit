
const applicationTitle = "scholar";

export {applicationTitle};
