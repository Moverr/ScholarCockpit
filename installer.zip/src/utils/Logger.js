 
export function log(message = null){
    if(message != null){
        console.log(message);
    }
}

export function logTable(data){
    console.table(data);
}

