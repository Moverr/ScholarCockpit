class BaseService{

    constructor() {
        
    }

}

export default BaseService;