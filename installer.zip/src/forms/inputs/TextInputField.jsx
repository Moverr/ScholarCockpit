import React from 'react'
import InputField from './InputField';



function TextInputField(props){
    return <InputField type="text" {...props} />; 
}
export default TextInputField;