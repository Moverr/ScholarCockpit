import React from 'react'
import InputField from './InputField';



function CheckboxField(props){
    return <InputField type="checkbox" {...props} />; 
}
export default CheckboxField;