import React from 'react'



function LabelField(props) {
    return <label className={props.className}>props.title</label>;
}
export default LabelField;