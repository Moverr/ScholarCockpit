import React  from 'react'
import { logTable } from '../../utils/Logger';

 

function Banner() {
 
  return (
    <div  className="banner  col-md-12">
      <h1 className="col-md-12"> SCHOLAR   </h1>
      <span className={"header-skirting"}>School Management System  v1.0 beta</span>
    </div>

  )

}
export default Banner;